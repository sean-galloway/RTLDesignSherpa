from .utils import write as write

__author__ = "Ali Hedayatnia, Student @ University of Tehra"
__date__ = "Apr. 2020"
__version__ = "1.0.0"
